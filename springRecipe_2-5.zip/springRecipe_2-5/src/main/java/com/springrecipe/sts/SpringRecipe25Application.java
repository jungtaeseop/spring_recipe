package com.springrecipe.sts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRecipe25Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRecipe25Application.class, args);
	}

}
